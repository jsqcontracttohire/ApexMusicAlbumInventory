prompt --application/pages/page_00300
begin
--   Manifest
--     PAGE: 00300
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>23143523579627459721
,p_default_application_id=>61355
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SQLEARNAPEX'
);
wwv_flow_api.create_page(
 p_id=>300
,p_user_interface_id=>wwv_flow_api.id(24726977224819892139)
,p_name=>'DJ FLYS ALBUM CARDS'
,p_alias=>'DJ-FLYS-ALBUM-CARDS'
,p_step_title=>'DJ FLYS ALBUM CARDS'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(24726830843727892047)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JSQCONTRACTTOHIRE@YAHOO.COM'
,p_last_upd_yyyymmddhh24miss=>'20210809140707'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24736059645806395040)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24726897025567892093)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(24726830014489892046)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(24726954140407892121)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24736060218165395048)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24726859809239892078)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'DJFLYBYNIGHTWITHART'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(24736062386900395053)
,p_region_id=>wwv_flow_api.id(24736060218165395048)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h2>Artist: &ARTIST.</h2>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<a href="&WIKILINK." target="_blank" title="Click Album name to visit Wiki Page"><h3>TITLE: &ALBUM_TITLE.</h3></a>'
,p_body_adv_formatting=>true
,p_body_html_expr=>'<h4>Genre: &GENRE.</h4>'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<h3>Running Time: &RUNNING_TIME.</h3>'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'ALBUM_ART'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
,p_media_description=>'&WIKILINK.'
,p_pk1_column_name=>'ID'
,p_mime_type_column_name=>'ALBUM_ART_MIMETYPE'
,p_last_updated_column_name=>'ALBUM_ART_LASTUPD'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24736060382257395048)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24726887694858892089)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_api.id(24736060218165395048)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_07=>'Y'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24736061112528395051)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(24726857616911892077)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23349940302410573946)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(24736060382257395048)
,p_button_name=>'addalbum'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24726952733744892120)
,p_button_image_alt=>'Add Album'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23349940264582573945)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(24736060382257395048)
,p_button_name=>'AddArtist'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24726952733744892120)
,p_button_image_alt=>'Add  Artist'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'https://apex.oracle.com/pls/apex/sq_learn_apex/r/music-artists/music-artists-report'
,p_button_css_classes=>'170px w240p'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24736061679553395052)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(24736061112528395051)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(24726952868970892120)
,p_button_image_alt=>'Reset'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RR,300::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24736060893340395051)
,p_name=>'P300_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(24736060382257395048)
,p_prompt=>'Search'
,p_source=>'ARTIST,ALBUM_TITLE,RUNNING_TIME,CERTIVICATIONS,ALBUM_ART_FILENAME,ALBUM_ART_MIMETYPE,ALBUM_ART_CHARSET'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_fc_collapsible=>true
,p_fc_initial_collapsed=>false
,p_fc_show_chart=>false
);
wwv_flow_api.component_end;
end;
/
