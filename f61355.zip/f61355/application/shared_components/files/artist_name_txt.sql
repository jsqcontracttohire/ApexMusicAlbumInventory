prompt --application/shared_components/files/artist_name_txt
begin
--   Manifest
--     APP STATIC FILES: 61355
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>23143523579627459721
,p_default_application_id=>61355
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SQLEARNAPEX'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E6172746973742D6E616D65207B0A0A666F6E742D7765696768743A20626F6C643B0A0A666F6E742D7374796C653A206974616C69633B0A0A666F6E742D73697A653A2031312E35656D3B0A0A7D';
wwv_flow_api.create_app_static_file(
 p_id=>wwv_flow_api.id(24741086268952817485)
,p_file_name=>'artist-name.txt'
,p_mime_type=>'text/plain'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
